#include <stdio.h>
#include <string.h>

struct student {
    char name[64]; //氏名
    int height;    //身長
    float weight;  //体重
};

int main(void){
    struct student Muji;
    struct student Kitty;

    strcpy(Muji.name, "Seiji");
    Muji.height = 182;
    Muji.weight = 67.5;

    strcpy(Kitty.name, "Kitty");
    Kitty.height = 50;  //りんご(10cm/個)5個分
    Kitty.weight = 1.5; //りんご(0.5kg/個)3個分

    printf("%sの身長は%dcmで、体重は%.1fです。\n", Muji.name,Muji.height,Muji.weight);
    printf("%sの身長は%dcmで、体重は%.1fです。\n", Kitty.name,Kitty.height,Kitty.weight);

    return 0;

};