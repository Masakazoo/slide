#include <iostream>
#include <string>
using namespace std;

class Student {
    public:
        string name;
        int height;
        float weight;
        void greeting();
};

void Student::greeting() {
    cout << name << "の身長は" << height << "cmで、体重は" << weight << "kgです。\n";
}

int main(){
    Student Muji;
    Student Kitty;

    Muji.name = "Seiji";
    Muji.height = 182;
    Muji.weight = 67.5;
    Muji.greeting();

    Kitty.name = "Kitty";
    Kitty.height = 50;  //りんご(10cm/個)5個分
    Kitty.weight = 1.5; //りんご(0.5kg/個)3個分
    Kitty.greeting();

    return 0;
}