from dataclasses import dataclass
from dataclasses import field

@dataclass
class MyData:
    name: str
    weight: list[float] = field(default_factory=list)

    def __sum(self, y):
        out = 0
        for i in y:
            out += i
        return out
    def mean(self):
        s = self.__sum(self.weight)
        return s/len(self.weight)


if __name__ == '__main__':
    name = "Hogeko"
    data = [65.2,67.4,70.0,69.8,66.6]

    d_hogeko = MyData(name, data)
    print(f"入力は、{d_hogeko.name}さんのデータ")

    data_mean = d_hogeko.mean()
    print(f"mean: {data_mean}")

