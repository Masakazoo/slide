from dataclasses import dataclass
from dataclasses import field

@dataclass
class MyData:
    name: str
    weight: list[float] = field(default_factory=list)

    def __sum(self, y):
        out = 0
        for i in y:
            out += i
        return out
    def mean(self):
        s = self.__sum(self.weight)
        return s/len(self.weight)
