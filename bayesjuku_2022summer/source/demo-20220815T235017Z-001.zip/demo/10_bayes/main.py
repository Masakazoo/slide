import numpy as np
import pandas as pd
from scipy.stats import zscore

import numpyro
from numpyro.infer import MCMC, NUTS, Predictive
import numpyro.distributions as dist
import jax

path = "../00_data/penguins_lter.csv"

use = ['Sample Number', 'Species','Culmen Length (mm)', 'Culmen Depth (mm)', 'Flipper Length (mm)', 'Body Mass (g)', 'Sex']
header = ['sample_number', 'species','culmen_length_mm', 'culmen_depth_mm', 'flipper_length_mm', 'body_mass_g', 'sex']

species = {'Adelie Penguin (Pygoscelis adeliae)': 'Adelie',
       'Chinstrap penguin (Pygoscelis antarctica)': 'Chinstrap',
       'Gentoo penguin (Pygoscelis papua)': 'Gentoo'}

df_raw = pd.read_csv(path, usecols=use)
df_shrink = df_raw.set_axis(header, axis='columns').dropna()
df = df_shrink.replace(species)
print(df.shape)
df.head()

species_int = {'Adelie': 0, 'Chinstrap': 1, 'Gentoo': 2}

x_std = zscore(df.body_mass_g.values)
y_std = zscore(df.culmen_length_mm.values)
g = df.species.replace(species_int).values.astype(int)

def model(g, y, x):
    mu_intercept = numpyro.sample("mu_intercept", dist.Normal(0.0,100.0))
    sigma_intercept = numpyro.sample("sigma_intercept", dist.HalfCauchy(0.25))
    mu_slope = numpyro.sample("mu_slope", dist.Normal(0.0,100.0))
    sigma_slope = numpyro.sample("sigma_slope", dist.HalfCauchy(0.25))
    
    n_group = len(np.unique(np.array(g)))
    
    with numpyro.plate("plate_i", n_group):
        intercept = numpyro.sample("intercept", dist.Normal(mu_intercept, sigma_intercept))
        slope = numpyro.sample("slope", dist.Normal(mu_slope, sigma_slope))
    
    sigma = numpyro.sample("sigma", dist.HalfCauchy(1.0))
    link_function = intercept[g] + slope[g] * x
    
    with numpyro.plate("data", len(g)):
        numpyro.sample("obs", dist.Normal(link_function, sigma), obs=y)
#-

numpyro.set_platform('cpu')
numpyro.set_host_device_count(4)

samples = 10000
burnin = 4000
num_chain = 4

nuts_kernel = NUTS(model)


mcmc = MCMC(nuts_kernel, num_samples=samples, num_warmup=burnin, num_chains=num_chain)
rng_key = jax.random.PRNGKey(0)

mcmc.run(rng_key, g, y_std, x_std)

posterior_samples = mcmc.get_samples()

mcmc.print_summary(prob=0.95)