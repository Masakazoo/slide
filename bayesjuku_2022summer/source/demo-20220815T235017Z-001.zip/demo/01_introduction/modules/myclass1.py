class MyClass1:
    def __init__(self, x,y,z):
        self.x = x
        self.y = y
        self.z = z
    def printsum(self):
        l = [self.x, self.y, self.z]
        print(sum(l))

class MyClass2:
    def __init__(self, name):
        self.name = name
    def greeting(self):
        print(f"Hello {self.name}!!")


if __name__ == '__main__':
    mc1 = MyClass1(1,2,3)
    mc2 = MyClass2("Seiji")

    mc1.printsum()
    # output: 6

    mc2.greeting()
    # output: Hello Seiji!!

