def mean(x):
    m = sum(x) / len(x)
    return m
#--

def print_m(val):
    print(f"{val}ですね")
#--
    
