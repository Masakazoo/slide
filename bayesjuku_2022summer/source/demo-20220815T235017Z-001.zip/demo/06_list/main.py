

l = []
for i in range(10):
    l.append(i)
#--

ll = [i for i in range(10)]

res1: list[bool] = []
for i in ll:
    if i % 2 == 0:
        res1.append(True)
    else:
        res1.append(False)
#--

res2: list[bool] = []
for i in ll:
    res2.append(True if i % 2 == 0 else False)
#--

res3: list[bool] = [True if i % 2 == 0 else False for i in range(10)]

print("res1: ", res1)
print("res2: ", res2)
print("res3: ", res3)